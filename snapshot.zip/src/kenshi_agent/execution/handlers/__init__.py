"""Cohesive operation handler families."""
