from __future__ import annotations

import json
from pathlib import Path

from ..core.observation import Observation
from ..core.operation import StopAction
from ..core.planner_context import AuthoredPlannerContext
from ..core.planning import (
    PlanEnvelope,
    PlannerDecision,
    PlannerOutput,
    PlanPatch,
)
from .base import Planner, PreparedPlannerInput, planner_context_manifest


class ScriptedPlanner(Planner):
    def __init__(self, path: Path) -> None:
        self.path = path
        self._decisions = self._load(path)
        self._index = 0

    @staticmethod
    def _load(path: Path) -> list[PlannerOutput]:
        decisions: list[PlannerOutput] = []
        with path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                try:
                    payload = json.loads(stripped)
                    if "replace_future_steps" in payload:
                        decisions.append(PlanPatch.model_validate(payload))
                    elif "steps" in payload:
                        decisions.append(PlanEnvelope.model_validate(payload))
                    else:
                        decisions.append(PlannerDecision.model_validate(payload))
                except Exception as exc:
                    raise ValueError(
                        f"Invalid scripted decision at {path}:{line_number}: {exc}"
                    ) from exc
        return decisions

    async def decide(self, observation: Observation) -> PlannerOutput:
        if self._index >= len(self._decisions):
            return PlannerDecision(
                intent="End the scripted episode.",
                rationale="The scripted decision file is exhausted.",
                action=StopAction(reason="Script exhausted."),
                confidence=1.0,
            )
        decision = self._decisions[self._index]
        self._index += 1
        return decision

    def prepare_input(
        self,
        observation: Observation,
        *,
        context_id: str,
    ) -> PreparedPlannerInput:
        """A script consumes its file, not IDs from the current observation."""

        return PreparedPlannerInput(
            context=AuthoredPlannerContext(
                manifest=planner_context_manifest(
                    observation,
                    context_id=context_id,
                    input_kind="scripted",
                ),
                observation=observation,
            )
        )
