import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from kenshi_agent.core.observation import Observation
from kenshi_agent.core.operation import (
    ClickAction,
    ControlMode,
    NoopAction,
    PerformContextAction,
    PlanningMode,
    ScrollAction,
    parse_action,
)
from kenshi_agent.core.planning import (
    Condition,
    ConditionKind,
    ConditionOperator,
    PlannerDecision,
    PlanStep,
)
from kenshi_agent.core.telemetry import (
    CharacterState,
    ContextActionKind,
    Disposition,
    GameState,
    KnownMapDestination,
    NearbyEntity,
    NormalizedPointerBounds,
    TelemetrySnapshot,
    UIState,
    Vec3,
    VisibleUIControl,
    WorldTarget,
)
from kenshi_agent.core.world import WorldStateRevision
from kenshi_agent.planner_context import render_planner_payload
from kenshi_agent.tooling.schema_export import export_schemas


def test_checked_in_jsonl_planner_examples_parse_as_current_decisions() -> None:
    examples = Path(__file__).resolve().parents[1] / "examples"
    planner_examples = sorted(examples.glob("*.jsonl"))
    assert planner_examples

    for path in planner_examples:
        for line_number, line in enumerate(
            path.read_text(encoding="utf-8").splitlines(),
            start=1,
        ):
            if line.strip():
                try:
                    PlannerDecision.model_validate_json(line)
                except ValidationError as exc:
                    raise AssertionError(
                        f"{path.name}:{line_number} is not a current planner decision"
                    ) from exc


def test_nearby_entity_visibility_is_unknown_until_observed() -> None:
    entity = NearbyEntity(id="nearby:0", name="Bar Trader", kind="character")

    assert entity.visible is None
    assert entity.position is None
    assert entity.camera_bearing_degrees is None
    assert entity.screen_position is None
    assert entity.shop_inventory_owner is None


def test_known_map_destination_is_a_first_class_observed_identity() -> None:
    payload = TelemetrySnapshot().model_dump(mode="python")
    payload["known_map_destinations"] = [
        {
            "id": "entity-known-town",
            "name": "The Hub",
            "distance": 1250.0,
            "has_gates": False,
        }
    ]

    snapshot = TelemetrySnapshot.model_validate(payload)

    assert snapshot.known_map_destinations[0].id == "entity-known-town"
    assert snapshot.known_map_destinations[0].name == "The Hub"
    assert snapshot.known_map_destinations[0].distance == 1250.0
    assert snapshot.known_map_destinations[0].has_gates is False


def test_location_capability_requires_one_complete_exact_town_observation() -> None:
    with pytest.raises(ValidationError, match="populated together"):
        TelemetrySnapshot(
            capabilities=["game.location", "game.location.identity"],
            game=GameState(
                loaded=True,
                location_id="entity-squin",
                location_name="Squin",
            ),
        )

    snapshot = TelemetrySnapshot(
        capabilities=["game.location", "game.location.identity"],
        game=GameState(
            loaded=True,
            location_id="entity-squin",
            location_name="Squin",
            inside_town_walls=False,
        ),
    )

    assert snapshot.game.location_id == "entity-squin"
    assert snapshot.game.inside_town_walls is False


def test_known_map_destination_digest_separates_identity_from_travel_eligibility() -> None:
    state = Observation(
        run_id="map-digest",
        step_index=0,
        mode="mock",
        world_revision=WorldStateRevision(telemetry_sequence=1),
        telemetry=TelemetrySnapshot(
            sequence=1,
            known_map_destinations=[
                KnownMapDestination(id="near", name="The Hub", distance=5.0),
                KnownMapDestination(id="far", name="Squin", distance=17500.0),
            ],
        ),
    )

    assert state.known_map_destination_digest() == [
        {
            "id": "near",
            "name": "The Hub",
            "distance": 5.0,
            "travel_available": False,
        },
        {
            "id": "far",
            "name": "Squin",
            "distance": 17500.0,
            "travel_available": True,
        },
    ]


def test_known_map_destination_digest_marks_exact_current_town_reached() -> None:
    state = Observation(
        run_id="map-location-digest",
        step_index=0,
        mode="mock",
        world_revision=WorldStateRevision(telemetry_sequence=1),
        telemetry=TelemetrySnapshot(
            sequence=1,
            capabilities=["game.location", "game.location.identity"],
            game=GameState(
                loaded=True,
                location_id="entity-squin",
                location_name="Squin",
                inside_town_walls=True,
            ),
            known_map_destinations=[
                KnownMapDestination(
                    id="entity-squin",
                    name="Squin",
                    distance=1300.0,
                    has_gates=True,
                ),
                KnownMapDestination(
                    id="entity-admag",
                    name="Admag",
                    distance=9000.0,
                    has_gates=True,
                ),
            ],
        ),
    )

    assert state.known_map_destination_digest() == [
        {
            "id": "entity-squin",
            "name": "Squin",
            "distance": 1300.0,
            "has_gates": True,
            "travel_available": False,
        },
        {
            "id": "entity-admag",
            "name": "Admag",
            "distance": 9000.0,
            "has_gates": True,
            "travel_available": True,
        },
    ]


def test_plan_step_normalizes_duplicate_conditions_at_the_schema_boundary() -> None:
    condition = Condition(
        kind=ConditionKind.TELEMETRY_FRESH,
        operator=ConditionOperator.EQUALS,
        expected=True,
        max_age_seconds=3.0,
    )

    step = PlanStep(
        step_id="inspect",
        action=NoopAction(reason="Read the current observation."),
        preconditions=[condition, condition, condition],
        success_conditions=[condition, condition],
        failure_conditions=[condition, condition],
        timeout_seconds=1.0,
    )

    assert step.preconditions == [condition]
    assert step.success_conditions == [condition]
    assert step.failure_conditions == [condition]


def test_visible_ui_control_exposes_resolution_independent_center() -> None:
    control = VisibleUIControl(
        label="Continue",
        role="button",
        bounds=NormalizedPointerBounds(
            min_x=0.2,
            max_x=0.4,
            min_y=0.1,
            max_y=0.2,
        ),
    )

    assert control.center == pytest.approx((0.3, 0.15))


def test_stable_identity_snapshot_requires_consistent_selection_and_unique_ids() -> None:
    snapshot = TelemetrySnapshot(
        protocol_version="0.2.0",
        identity_session_id="session-process-1",
        capabilities=["squad.basic", "nearby.characters", "identity.stable_handles"],
        ui=UIState(
            selected_character_id="entity-player",
            selected_character_ids=["entity-player"],
        ),
        squad=[
            CharacterState(
                id="entity-player",
                name="Wanderer",
                selected=True,
            )
        ],
        nearby_entities=[NearbyEntity(id="entity-vendor", name="Barman", kind="character")],
    )

    assert snapshot.identity_session_id == "session-process-1"

    invalid_selection = snapshot.model_dump(mode="python")
    invalid_selection["ui"] = UIState(
        selected_character_id="entity-missing",
        selected_character_ids=["entity-missing"],
    )
    with pytest.raises(ValidationError, match="must refer to current squad IDs"):
        TelemetrySnapshot.model_validate(invalid_selection)

    with pytest.raises(ValidationError, match="must be unique"):
        TelemetrySnapshot(
            protocol_version="0.2.0",
            identity_session_id="session-process-1",
            capabilities=["identity.stable_handles"],
            squad=[CharacterState(id="entity-shared", name="Wanderer")],
            nearby_entities=[NearbyEntity(id="entity-shared", name="Barman", kind="character")],
        )
    with pytest.raises(ValidationError, match="must be unique"):
        TelemetrySnapshot(
            protocol_version="0.8.0",
            identity_session_id="session-process-1",
            capabilities=["identity.stable_handles"],
            squad=[CharacterState(id="entity-shared", name="Wanderer")],
            world_targets=[
                WorldTarget(
                    id="entity-shared",
                    name="Copper Resource",
                    kind="natural_resource",
                    position=Vec3(x=1.0, y=0.0, z=2.0),
                    distance=10.0,
                    context_actions=[ContextActionKind.OPERATE],
                    default_task="operate_machinery",
                )
            ],
        )

    squad_context_target = TelemetrySnapshot(
        protocol_version="1.9.0",
        identity_session_id="session-process-1",
        capabilities=["identity.stable_handles"],
        squad=[CharacterState(id="entity-injured", name="Bark")],
        world_targets=[
            WorldTarget(
                id="entity-injured",
                name="Bark",
                kind="squad_character",
                position=Vec3(x=1.0, y=0.0, z=2.0),
                distance=10.0,
                context_actions=[ContextActionKind("first_aid")],
                default_task="first_aid",
            )
        ],
    )
    assert squad_context_target.world_targets[0].id == squad_context_target.squad[0].id


def test_action_discriminator_parses_click() -> None:
    action = parse_action(
        {
            "kind": "click",
            "x": 0.25,
            "y": 0.75,
            "space": "normalized",
            "button": "left",
        }
    )
    assert isinstance(action, ClickAction)
    assert action.x == 0.25
    assert action.hold_seconds == 0.0


def test_action_discriminator_parses_context_action() -> None:
    action = parse_action(
        {
            "kind": "perform_context_action",
            "target_id": "entity-copper",
            "context_action": "operate",
        }
    )

    assert isinstance(action, PerformContextAction)
    assert action.context_action == ContextActionKind.OPERATE


def test_context_action_semantics_are_runtime_extensible_not_enumerated() -> None:
    action = PerformContextAction(
        target_id="entity-medic",
        context_action="first_aid",
    )
    target = WorldTarget(
        id="entity-medic",
        name="Downed Wanderer",
        kind="character",
        position=Vec3(x=1.0, y=0.0, z=2.0),
        distance=3.0,
        context_actions=["first_aid", "rescue"],
        default_task="first_aid",
    )

    assert action.context_action.value == "first_aid"
    assert [order.value for order in target.context_actions] == [
        "first_aid",
        "rescue",
    ]
    with pytest.raises(ValidationError):
        PerformContextAction(
            target_id="entity-medic",
            context_action="First Aid",
        )


def test_click_hold_is_bounded() -> None:
    assert ClickAction(x=0.5, y=0.5, hold_seconds=0.12).hold_seconds == 0.12
    with pytest.raises(ValidationError):
        ClickAction(x=0.5, y=0.5, hold_seconds=0.51)


def test_action_discriminator_parses_bounded_scroll() -> None:
    action = parse_action(
        {
            "kind": "scroll",
            "x": 0.5,
            "y": 0.45,
            "space": "normalized",
            "notches": 1,
        }
    )

    assert isinstance(action, ScrollAction)
    assert action.notches == 1


def test_scroll_rejects_zero_and_excessive_notches() -> None:
    with pytest.raises(ValidationError):
        ScrollAction(x=0.5, y=0.5, notches=0)
    with pytest.raises(ValidationError):
        ScrollAction(x=0.5, y=0.5, notches=9)


def test_unknown_action_field_is_rejected() -> None:
    with pytest.raises(ValidationError):
        parse_action({"kind": "wait", "seconds": 1, "surprise": True})


def test_observation_planner_payload_omits_screenshot_path() -> None:
    observation = Observation(
        run_id="run",
        step_index=0,
        mode="mock",
        telemetry=TelemetrySnapshot(),
        screenshot_path=Path("secret-frame.png"),
        objective="Explore nearby.",
    )
    payload = render_planner_payload(
        observation,
    )
    assert "secret-frame.png" not in payload
    document = json.loads(payload)
    assert document["run_id"] == "run"
    assert document["objective"] == "Explore nearby."


def test_reviewed_world_target_is_an_exact_attemptable_affordance() -> None:
    actor = CharacterState(id="entity-player", name="Player", selected=True)
    target = WorldTarget(
        id="entity-copper",
        name="Copper Resource",
        kind="natural_resource",
        position=Vec3(x=10.0, y=0.0, z=20.0),
        distance=30.0,
        context_actions=[ContextActionKind.OPERATE],
        default_task="operate_machinery",
        mining_resource_level=0.8,
    )
    observation = Observation(
        run_id="resource-perception",
        step_index=0,
        mode="mock",
        control_mode=ControlMode.NATIVE_ASSISTED,
        planning_mode=PlanningMode.CONTINUOUS,
        telemetry=TelemetrySnapshot(
            protocol_version="1.0.0",
            identity_session_id="resource-affordance-test",
            capabilities=[
                "world.context_targets",
                "control.perform_context_action",
                "game.pause",
                "identity.stable_handles",
            ],
            game=GameState(loaded=True, paused=True),
            ui=UIState(
                active_screen="world",
                dialogue_open=False,
                modal_open=False,
                selected_character_id=actor.id,
                selected_character_ids=[actor.id],
            ),
            squad=[actor],
            world_targets=[target],
        ),
    )

    payload = json.loads(
        render_planner_payload(
            observation,
        )
    )

    assert payload["telemetry"]["world_targets"] == [target.model_dump(mode="json")]
    context_offers = [
        offer for offer in payload["affordances"] if offer["source"] == "context_order"
    ]
    assert len(context_offers) == 1
    assert context_offers[0]["semantic"] == "operate"
    assert context_offers[0]["target"] == {
        "target_id": target.id,
        "label": target.name,
        "kind": target.kind,
    }


def test_schema_export_separates_affordance_contract_from_runtime_internals(
    tmp_path: Path,
) -> None:
    exported = {path.name for path in export_schemas(tmp_path)}

    assert "affordance_selection.schema.json" in exported
    assert "decision_proposal.schema.json" in exported
    assert "plan_proposal.schema.json" in exported
    assert "affordance_receipt.schema.json" in exported
    assert "runtime_operation.schema.json" in exported
    assert "runtime_decision.schema.json" in exported
    assert "runtime_plan.schema.json" in exported
    assert "runtime_plan_patch.schema.json" in exported
    assert "runtime_action_receipt.schema.json" in exported
    assert "native_command_request.schema.json" in exported
    assert "action.schema.json" not in exported
    assert "decision.schema.json" not in exported
    assert "plan.schema.json" not in exported
    assert "receipt.schema.json" not in exported


def _trade_observation(
    *,
    active_screen: str,
    open_inventory_windows: int,
    window_captions: list[str],
) -> Observation:
    """A world with squad members Hep and Puhat and a nearby shop-owning Barman."""

    return Observation(
        run_id="trade-predicate",
        step_index=0,
        mode="live",
        telemetry=TelemetrySnapshot(
            ui=UIState(
                active_screen=active_screen,
                open_inventory_windows=open_inventory_windows,
                visible_controls=[
                    VisibleUIControl(
                        label=f"item_{index}",
                        role="item",
                        window=caption,
                        bounds=NormalizedPointerBounds(
                            min_x=0.30,
                            max_x=0.34,
                            min_y=0.20,
                            max_y=0.24,
                        ),
                    )
                    for index, caption in enumerate(window_captions)
                ],
            ),
            squad=[
                CharacterState(id="player:1", name="Hep", selected=True),
                CharacterState(id="player:2", name="Puhat"),
            ],
            nearby_entities=[
                NearbyEntity(
                    id="seller:1",
                    name="Barman",
                    shop_inventory_owner=True,
                    disposition=Disposition.NEUTRAL,
                )
            ],
        ),
    )


def test_trade_needs_a_shop_owned_window_not_merely_two_open_ones() -> None:
    """Two of your own bags open is item shuffling, not a trade.

    Kenshi lets you open two squad inventories side by side to move gear
    between characters. That is the same window count as a trade, so a
    purchase must be refused there while being allowed against a real shop.
    """

    trade = _trade_observation(
        active_screen="inventory",
        open_inventory_windows=2,
        window_captions=["HEP", "BARMAN"],
    )
    own_gear = _trade_observation(
        active_screen="inventory",
        open_inventory_windows=2,
        window_captions=["HEP", "PUHAT"],
    )

    assert trade.trade_screen_open() is True
    assert trade.vendor_inventory_windows() == ["BARMAN"]
    assert own_gear.trade_screen_open() is False
    assert own_gear.vendor_inventory_windows() == []


def test_trade_predicate_needs_the_shop_window_actually_open() -> None:
    """A shop owner standing nearby is not a trade until its window is open."""

    nearby_only = _trade_observation(
        active_screen="inventory",
        open_inventory_windows=1,
        window_captions=["HEP"],
    )

    assert nearby_only.trade_screen_open() is False


def test_trade_predicate_still_trusts_an_explicit_trade_label() -> None:
    labelled = _trade_observation(
        active_screen="trade",
        open_inventory_windows=2,
        window_captions=["HEP", "BARMAN"],
    )

    assert labelled.trade_screen_open() is True


def _control(widget_name: str) -> VisibleUIControl:
    return VisibleUIControl(
        label="x",
        role="button",
        widget_name=widget_name,
        bounds=NormalizedPointerBounds(min_x=0.1, max_x=0.2, min_y=0.1, max_y=0.2),
    )


def test_a_widget_name_carries_the_window_it_belongs_to() -> None:
    """Windows are the only thing in this telemetry with no identity.

    Characters, resources, map destinations and dialogue targets all carry an
    opaque handle-derived ID; windows carry a caption and a count. MyGUI's
    per-load instance prefix is the identity that was already present and
    discarded, observed live grouping ten MainPanel widgets under one prefix.
    """

    build = _control("0,000,000,093,8E6,C50_BuildButton")
    speed = _control("0,000,000,093,8E6,C50_TimeSpeedButton1")
    other = _control("0,000,000,0EE,9EF,F40_BorderPanel")

    assert build.window_instance == speed.window_instance
    assert build.window_instance != other.window_instance
    assert build.layout_widget_name == "BuildButton"
    assert other.layout_widget_name == "BorderPanel"


def test_a_widget_whose_own_name_has_an_underscore_is_not_split() -> None:
    """`item_3` is a name, not an instance prefix and a widget."""

    cell = _control("item_3")

    assert cell.window_instance == ""
    assert cell.layout_widget_name == "item_3"


def test_an_unnamed_widget_reports_no_window_instance() -> None:
    assert _control("").window_instance == ""
