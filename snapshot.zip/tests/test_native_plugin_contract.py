from __future__ import annotations

from pathlib import Path

from kenshi_agent.operation_definitions import NATIVE_WALK_DESTINATION_REACHED_RESULT

REPO_ROOT = Path(__file__).resolve().parents[1]
PLUGIN_SOURCE = REPO_ROOT / "native" / "KenshiAgentTelemetry" / "KenshiAgentTelemetry.cpp"
PROTOCOL_SOURCE = (
    REPO_ROOT
    / "native"
    / "KenshiAgentTelemetry"
    / "NativeCommandProtocol.cpp"
)
ATOMIC_WRITER_SOURCE = (
    REPO_ROOT / "native" / "KenshiAgentTelemetry" / "AtomicJsonWriter.cpp"
)
PLUGIN_PROJECT = (
    REPO_ROOT
    / "native"
    / "KenshiAgentTelemetry"
    / "KenshiAgentTelemetry.vcxproj"
)


def test_native_plugin_does_not_export_unvalidated_raw_getting_eaten_byte() -> None:
    source = PLUGIN_SOURCE.read_text(encoding="utf-8")

    assert "character->isGettingEaten" not in source
    assert "getting-eaten state" in source


def test_native_plugin_exports_nearby_character_and_ui_signals() -> None:
    source = PLUGIN_SOURCE.read_text(encoding="utf-8")

    assert "getCharactersWithinSphere" in source
    assert "ShopTraderConstructorHook" in source
    assert "ShopTraderDestructorHook" in source
    assert "GameWorldResetHook" in source
    assert "GetRealAddress(&GameWorld::resetGame)" in source
    assert "ResetSessionState();" in source
    assert "NEARBY_CHARACTER_RADIUS = 400.0f" in source
    # Every nearby-character sweep must use the one radius, so telemetry and
    # both command lookups agree about what counts as nearby. Counting the
    # uses pinned an incidental number; what matters is that nothing sweeps
    # with a literal of its own.
    assert "getCharactersWithinSphere" in source
    for call in source.split("getCharactersWithinSphere(")[1:]:
        assert "NEARBY_CHARACTER_RADIUS" in call.split(")")[0], (
            "a nearby-character sweep used a radius of its own"
        )
    assert "IsTrackedShopOwner(target)" in source
    assert "platoon->getIsTrader()" in source
    assert "platoon->getHasVendorList()" in source
    assert "platoon->getSquadLeader() == target" in source
    assert "target->hasDialogue()" in source
    assert "ProcessNativeCommandRequest" in source
    assert "newPlayerTaskSelectedCharacters" in source
    assert "VK_F10" in source
    assert "AppendVector3(json, targetPosition)" in source
    assert "target->isOnScreen" in source
    assert "target->getVisible()" in source
    assert "getViewMatrix()" in source
    assert "worldToScreenRel" in source
    assert "camera_bearing_degrees" in source
    assert "std::atan2(cameraX, -cameraZ)" in source
    assert "screen_position" in source
    assert "gui->isAnyInventoryWindowOpen()" in source
    assert "gui->dialogue->isVisible()" in source
    assert '"trade"' in source
    assert "geometry can still" in source


def test_native_plugin_uses_session_scoped_validated_handle_identity() -> None:
    source = PLUGIN_SOURCE.read_text(encoding="utf-8")

    assert "identity_session_id" in source
    assert "CreateProcessGeneration()" in source
    assert "++g_sessionGeneration;" in source
    assert "StableEntityId(const hand& handle)" in source
    assert "if (!handle.isValid())" in source
    assert "handle.containerSerial" in source
    assert "handle.serial" in source
    assert "SameHandleIdentity(*it, handle)" in source
    assert "selectedCharacters.find" not in source
    assert "selected_character_ids" in source
    assert "last_target_id" in source
    assert "squad:" not in source
    assert "nearby:" not in source


def test_native_plugin_requires_causal_exact_target_command_requests() -> None:
    source = PLUGIN_SOURCE.read_text(encoding="utf-8")

    assert "native_command.request.json" in source
    assert "ProcessNativeCommandRequest" in source
    assert "FindExactDialogueTarget" in source
    assert "FindNearestConfirmedVendor" not in source
    assert "identity_session_id" in source
    assert "native_assisted" in source
    assert "selected_character_ids" in source
    assert "duplicate_command_id" in source
    assert "stale_revision" in source
    assert "selection_mismatch" in source
    assert "target_lifetime_changed" in source
    assert "target_role_invalid" in source
    assert "exact_dialogue_target_open" in source
    assert "acknowledgements" in source
    assert "MAX_NATIVE_ACKNOWLEDGEMENTS = 16" in source
    assert "MonitorActiveNativeCommand" in source
    monitor = source[source.index("void MonitorActiveNativeCommand") :]
    assert monitor.index("IsExactDialogueTargetOpen") < monitor.index(
        "ObserveNativeMovementPause"
    )

def test_native_plugin_exports_food_chain_authoritative_ui_and_time_sources() -> None:
    source = PLUGIN_SOURCE.read_text(encoding="utf-8")

    assert "#include <kenshi/gui/ToolTip.h>" in source
    assert "getTimeStamp_inGameHours().getTotalMinutes()" in source
    assert "TryGetDialogueTargetId" in source
    assert "replyTexts" in source
    assert "getCaption().asUTF8()" in source
    assert "gui->getToolTip()" in source
    assert "tooltip->getVisible()" in source
    assert "tooltip->caller->getAbsoluteCoord()" in source
    assert "tooltip_source_bounds" in source

    project = PLUGIN_PROJECT.read_text(encoding="utf-8")
    assert project.count("MyGUIEngine_x64.lib") == 2


def test_native_plugin_exports_bounded_visible_semantic_ui_controls() -> None:
    source = PLUGIN_SOURCE.read_text(encoding="utf-8")

    assert "#include <mygui/MyGUI_Gui.h>" in source
    assert "#include <kenshi/gui/TitleScreen.h>" in source
    assert "BuildTitleSnapshot" in source
    assert '"capabilities\\\":[\\\"ui.visible_controls\\\"]' in source
    assert '"game\\\":{\\\"loaded\\\":false}' in source
    assert '"source\\\":\\\"kenshilib-plugin-title\\\"' in source
    assert "GetRealAddress(&TitleScreen::_NV_update)" in source
    assert "TitleScreenUpdateHook" in source
    assert "g_originalTitleScreenUpdate(titleScreen);" in source
    assert "Sample(NULL, true);" in source
    title_builder = source.split("std::string BuildTitleSnapshot()", 1)[1].split(
        "void WriteStatus",
        1,
    )[0]
    for forbidden_loaded_state in (
        "ou->",
        "player->",
        "gui->",
        "selected->",
        "g_activeNativeCommand",
    ):
        assert forbidden_loaded_state not in title_builder
    assert "eventFrameStart" not in source
    assert "GetProcAddress" not in source
    assert "?frameEvent@Gui@MyGUI" not in source
    assert "ou->initialized &&" in source
    assert "(ou == NULL || !ou->initialized)" in source
    assert "Sample(player, false);" in source
    assert "ui.visible_controls" in source
    assert "AppendVisibleUIControls" in source
    # The plug-in's export cap must never exceed the model's bound, or a rich
    # screen fails validation outright instead of arriving truncated.
    import re

    from kenshi_agent.core.telemetry import UIState

    match = re.search(r"MAX_VISIBLE_UI_CONTROLS = (\d+)", source)
    assert match is not None
    native_cap = int(match.group(1))
    model_bound = UIState.model_fields["visible_controls"].metadata[0].max_length
    assert native_cap <= model_bound, (
        f"plug-in exports up to {native_cap} controls but the model accepts "
        f"at most {model_bound}"
    )
    assert "MAX_VISITED_UI_WIDGETS = 2048" in source
    assert "MAX_UI_WIDGET_DEPTH = 32" in source
    assert "getInheritedVisible()" in source
    assert "getInheritedEnabled()" in source
    assert "getAbsoluteCoord()" in source
    assert 'widget->castType<MyGUI::Button>(false)' in source


def test_native_sampler_recovers_from_transient_write_and_cpp_failures() -> None:
    plugin = PLUGIN_SOURCE.read_text(encoding="utf-8")
    writer = ATOMIC_WRITER_SOURCE.read_text(encoding="utf-8")

    assert "SamplingGuard samplingGuard(g_sampling);" in plugin
    assert "catch (const std::exception& exception)" in plugin
    assert "catch (...)" in plugin
    assert "maximumMoveAttempts = 4" in writer
    assert "ERROR_SHARING_VIOLATION" in writer
    assert "ERROR_LOCK_VIOLATION" in writer


def test_native_approach_authorizes_any_valid_dialogue_target() -> None:
    """The native fence must ask "can I talk to this person", not "is this a shop".

    Kenshi's PLAYER_TALK_TO order works on any non-hostile character with
    dialogue. Requiring a vendor list and squad leadership excluded ordinary
    people for no safety reason, which is exactly the coupling the reusable
    approach action exists to remove.
    """

    source = PLUGIN_SOURCE.read_text(encoding="utf-8")

    assert "IsValidDialogueTarget" in source
    # The approach command and its continued-ownership check both use the
    # generic fence.
    assert "return IsValidDialogueTarget(selected, candidate) ? candidate : NULL;" in source
    assert "if (!IsValidDialogueTarget(selected, target))" in source

    generic = source[
        source.index("bool IsValidDialogueTarget") : source.index("bool IsConfirmedVendor")
    ]
    assert "hasDialogue()" in generic
    assert "isUnconcious()" in generic
    assert "isEnemy(" in generic
    assert "isAnimal()" in generic
    # The commerce-specific conditions must not gate a generic approach.
    assert "getHasVendorList" not in generic
    assert "getSquadLeader" not in generic

    # Vendor status survives as its own narrower predicate for callers that
    # genuinely mean commerce.
    vendor = source[source.index("bool IsConfirmedVendor") :]
    vendor = vendor[: vendor.index("Character* FindExactDialogueTarget")]
    assert "IsValidDialogueTarget(selected, target)" in vendor
    assert "getHasVendorList" in vendor
    assert "getSquadLeader" in vendor


def test_request_key_allowlists_are_counted_not_restated() -> None:
    """A literal count outlives the list it describes.

    `HasOnlyKeys(root, rootKeys, 8)` kept saying 8 after two keys were added for
    directional movement, so those keys fell outside the allowed range and every
    native command was rejected as malformed - including the approach that had
    worked for weeks. The count must come from the array.
    """
    source = PROTOCOL_SOURCE.read_text(encoding="utf-8")
    for call in source.split("HasOnlyKeys(")[1:]:
        arguments = call.split(")")[0]
        if "const char* const*" in arguments:
            continue  # the declaration itself
        assert "ARRAY_COUNT(" in arguments, (
            f"a key allowlist restated its length instead of counting it: {arguments}"
        )


def test_targetless_direction_uses_the_shared_native_protocol_module() -> None:
    plugin = PLUGIN_SOURCE.read_text(encoding="utf-8")
    protocol = PROTOCOL_SOURCE.read_text(encoding="utf-8")
    project = PLUGIN_PROJECT.read_text(encoding="utf-8")

    assert '#include "NativeCommandProtocol.h"' in plugin
    assert "NativeCommandProtocol.cpp" in project
    assert "request.targetId.empty()" in protocol
    # Command shape is classified once, by the shared module, rather than by
    # each caller re-spelling the name. The parser and the dispatcher both went
    # through their own copies until a survey command had to be added to both.
    assert "NativeCommandCarriesDirection" in protocol
    assert 'command == "move_in_direction"' in protocol
    assert "request.distanceUnits > 0.0" in protocol
    assert "acknowledgement.bearingDegrees" in protocol
    assert "acknowledgement.distanceUnits" in protocol
    assert "SerializeNativeCommandAcknowledgement" in plugin


def test_parameterless_building_exit_resolves_a_native_outdoor_door_point() -> None:
    plugin = PLUGIN_SOURCE.read_text(encoding="utf-8")
    protocol = PROTOCOL_SOURCE.read_text(encoding="utf-8")

    # Parameterless commands are the ones the shared classifier recognises
    # while naming neither a target nor a direction.
    assert "IsKnownNativeCommand" in protocol
    assert 'command == "exit_current_building"' in protocol
    assert "walker->isIndoors()" in plugin
    assert "building->doors.begin()" in plugin
    assert "door->isLocked()" in plugin
    assert "door->getDoorPosOutside_extraFarOut" in plugin
    assert "ObserveNativeOutdoorConfirmation" in plugin
    assert '"left_current_building"' in plugin
    assert '"no_usable_exit"' in plugin


def test_native_movement_pause_timing_uses_the_shared_conformance_module() -> None:
    plugin = PLUGIN_SOURCE.read_text(encoding="utf-8")
    tests = (
        PLUGIN_SOURCE.parent / "NativeCommandProtocolTests.cpp"
    ).read_text(encoding="utf-8")
    project = PLUGIN_PROJECT.read_text(encoding="utf-8")

    assert '#include "NativeCommandTiming.h"' in plugin
    assert "NativeCommandTiming.cpp" in project
    assert "ObserveNativeMovementPause" in plugin
    assert "MAX_PAUSED_TICKS_WHILE_MOVING" not in plugin
    assert '#include "NativeCommandTiming.cpp"' in tests
    assert "movement cancelled before its accepted snapshot" in tests
    assert "movement cancelled during a bounded pulse gap" in tests


def test_native_direction_completion_uses_the_shared_conformance_module() -> None:
    plugin = PLUGIN_SOURCE.read_text(encoding="utf-8")
    tests = (
        PLUGIN_SOURCE.parent / "NativeCommandProtocolTests.cpp"
    ).read_text(encoding="utf-8")
    project = PLUGIN_PROJECT.read_text(encoding="utf-8")

    assert '#include "NativeMovementSemantics.h"' in plugin
    assert "NativeMovementSemantics.cpp" in project
    assert "HasReachedFixedDirectionDestination" in plugin
    assert '#include "NativeMovementSemantics.cpp"' in tests
    assert "purely sideways movement completed a direction" in tests
    assert "short movement outside tolerance completed a direction" in tests
    assert "crossing the destination plane did not complete" in tests


def test_native_movement_stall_uses_the_shared_conformance_module() -> None:
    plugin = PLUGIN_SOURCE.read_text(encoding="utf-8")
    tests = (
        PLUGIN_SOURCE.parent / "NativeCommandProtocolTests.cpp"
    ).read_text(encoding="utf-8")

    assert "ObserveNativeMovementStall" in plugin
    assert '"movement_stalled"' in plugin
    assert "blocked movement did not stall at its exact limit" in tests
    assert "progress did not reset the stall interval" in tests
    assert "stable outdoor state did not complete at its limit" in tests
    assert f'"{NATIVE_WALK_DESTINATION_REACHED_RESULT}"' in plugin


def test_native_resource_production_releases_only_command_owned_work() -> None:
    plugin = PLUGIN_SOURCE.read_text(encoding="utf-8")
    tests = (
        PLUGIN_SOURCE.parent / "NativeCommandProtocolTests.cpp"
    ).read_text(encoding="utf-8")

    assert "resourceTaskIssuedByCommand" in plugin
    assert "resourceTaskReleaseRequested" in plugin
    assert "EvaluateResourceTaskRelease" in plugin
    assert "walker->removeJob(" in plugin
    assert "resourceTasks->clearOrders()" in plugin
    assert "resourceTasks->hasPlayerOrders()" in plugin
    assert "resourceMovement->halt()" in plugin
    assert "resource_output_ready_task_released" in plugin
    assert "adopted resource work was claimed by the command" in tests
    assert "stable resource release did not confirm on time" in tests


def test_native_group_travel_requires_every_selected_member_at_each_leg() -> None:
    plugin = PLUGIN_SOURCE.read_text(encoding="utf-8")
    tests = (
        PLUGIN_SOURCE.parent / "NativeCommandProtocolTests.cpp"
    ).read_text(encoding="utf-8")
    map_monitor = plugin.split("if (mapTown != NULL)", 1)[1].split(
        "bool buildingExitIndoors",
        1,
    )[0]

    assert "if (selectedHandles.empty())" in plugin
    assert "HasGroupReachedDestination" in map_monitor
    assert "HasReachedFixedDirectionDestination" not in map_monitor
    assert "stallX" in map_monitor
    assert "member beyond another member's destination plane" in tests


def test_native_map_distance_uses_the_farthest_selected_member() -> None:
    plugin = PLUGIN_SOURCE.read_text(encoding="utf-8")
    collector = plugin.split("void CollectKnownMapDestinations", 1)[1].split(
        "TownBase* FindExactKnownMapDestination",
        1,
    )[0]
    exporter = plugin.split('json << "\\\"known_map_destinations\\\":["', 1)[1]

    assert "selectedPositions" in collector
    assert "HasGroupReachedDestination" in collector
    assert "farthestX" in collector
    assert "IsSelected(player, member->getHandle())" in exporter
