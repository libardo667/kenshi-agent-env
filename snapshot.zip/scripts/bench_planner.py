"""Time one real planning call per model, and check the plan survives validation.

Reads the live observation but sends no input: this measures the planner, not
the game. Latency is the number that matters - the executor's native fence has
about a half-second life, and a 25s round trip is what made plans stale.
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
from pathlib import Path

from kenshi_agent.config import AppConfig, load_config
from kenshi_agent.core.observation import Observation
from kenshi_agent.core.operation import (
    ControlMode,
    PlanningMode,
)
from kenshi_agent.core.world import WorldStateRevision
from kenshi_agent.planner_context import (
    planner_affordance_digest,
    render_planner_payload,
)
from kenshi_agent.planners.openrouter_planner import OpenRouterPlanner
from kenshi_agent.tooling.live_dev import _telemetry_read


def live_observation(config: AppConfig) -> Observation:
    snapshot = _telemetry_read(config).read().snapshot
    return Observation(
        run_id="bench", step_index=0, mode="live",
        control_mode=ControlMode.NATIVE_ASSISTED,
        planning_mode=PlanningMode.CONTINUOUS,
        world_revision=WorldStateRevision(telemetry_sequence=snapshot.sequence),
        telemetry=snapshot, telemetry_stale=False,
        objective="You're playing Kenshi. Decide a goal for yourself and work toward it.",
    )


async def main() -> int:
    config = load_config("config/live.yaml")
    obs = live_observation(config)
    payload = render_planner_payload(obs)
    assert obs.telemetry is not None
    print(
        f"observation: screen={obs.telemetry.ui.active_screen} "
        f"affordances_offered={len(planner_affordance_digest(obs))} "
        f"payload={len(payload)} chars\n"
    )

    trials = int(os.environ.get("TRIALS", "1"))
    models = sys.argv[1:] or ["openai/gpt-4.1-mini"]
    print(f"{'model':44s} {'secs':>6s}  verdict")
    tally: dict[str, list[tuple[bool, float]]] = {}
    for model in [m for m in models for _ in range(trials)]:
        cfg = config.planner.model_copy(update={
            "openrouter_model": model,
            "reasoning_effort": os.environ.get("REASONING", "none"),
            "include_screenshot": False,
        })
        planner = OpenRouterPlanner(cfg, Path("prompts/planner_system.md"))
        start = time.monotonic()
        try:
            out = await planner.decide(obs)
            secs = time.monotonic() - start
            steps = len(getattr(out, "steps", []) or [])
            kinds = [s.action.kind for s in getattr(out, "steps", []) or []]
            print(f"{model:44s} {secs:6.1f}  PLAN ok: {steps} steps {kinds}")
            goal = getattr(out, "goal", None)
            if goal:
                print(f"{'':44s}         goal: {goal[:90]}")
            tally.setdefault(model, []).append((True, secs))
        except Exception as exc:
            secs = time.monotonic() - start
            msg = f"{type(exc).__name__}: {exc}"
            print(f"{model:44s} {secs:6.1f}  FAILED {msg[:150]}")
            if os.environ.get("FULL_ERROR"):
                print("      FULL:", str(exc)[:1400])
            tally.setdefault(model, []).append((False, secs))

    print(f"\n{'model':44s} {'ok/n':>7s} {'median s':>9s}")
    for model, runs in tally.items():
        ok = sum(1 for good, _ in runs if good)
        times = sorted(s for _, s in runs)
        med = times[len(times) // 2]
        print(f"{model:44s} {ok:3d}/{len(runs):<3d} {med:9.1f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
